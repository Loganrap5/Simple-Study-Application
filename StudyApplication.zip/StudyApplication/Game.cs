﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace StudyApplication
{
    internal class Game
    {
        string input;

        string target;

        string[] answer1Array = new string[] { "19", "21", "21", "21" };

        int guess = 0;

        public void Play()
        {
            bool running = true;

            

            //answer1Array[0] = target;

            while (running == true)
            {
                //assign a value from answer1Array to the target value for correct answer

                //answer1Array[0] = target; 

                Console.WriteLine("What is 9 + 10?");

                foreach (string i in answer1Array)
                {
                    Console.WriteLine(i);

                }

                input = Console.ReadLine();

                if(input == answer1Array[0])
                {
                    Console.WriteLine("Congrats you guessed correct!!");
                    guess++;
                    running = false;
                    Play2();
                }
                else
                {
                    guess++;
                    Console.WriteLine($"Sorry {input} is incorrect.");
                    Console.WriteLine("Try again!!!");
                    Console.WriteLine("Press enter to continue");
                    Console.ReadLine();
                    Console.Clear();
                    
                    Play();

                }

                               





            }
            

            


            


        }
        string[] answer2Array = new string[] { "25", "15", "50", "100" };

        

        string target2;

        string input2;

        public void Play2()
        {
            bool running1 = true;

            while(running1 == true)
            {
                foreach (string i in answer2Array)
                {
                    Console.WriteLine(i);

                }

                Console.WriteLine("What is 5 x 10?");
                input2 = Console.ReadLine();

                if (input2 == answer2Array[2])
                {
                    guess++;
                    Console.WriteLine("Congrats you guessed correct!!");
                    running1 = false;
                    EndGame();

                }
                else
                {
                    guess++;
                    Console.WriteLine($"Sorry {input2} is incorrect.");
                    Console.WriteLine("Try again!!!");
                    Console.WriteLine("Press enter to continue");
                    Console.ReadLine();
                    Console.Clear();
                    Play2();

                }


            }


        }


        public void EndGame()
        {
            Console.WriteLine("Good job! You made it to the end of the study guide.");
            Console.WriteLine($"You guessed {guess} times. Not bad!");
            Console.WriteLine("Press enter to exit game...");
            Console.ReadLine();
            Environment.Exit(0);



        }













    }
}
